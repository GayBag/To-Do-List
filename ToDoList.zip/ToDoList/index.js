const express = require('express');
const app = express();
const {ToDoList} = require('./model');

require('hbs').registerPartials (__dirname + '/views/component');
app.set('view engine','hbs');

app.use(express.json());
app.use(express.urlencoded({extended:false})) 

app.get('/',async(req,res) =>{
    const arr = await ToDoList.findAll({
        attributes:['id','name']
    })
    res.render('showToDo',{arr})
})
app.get('/addToDo',async(req,res) =>{
    res.render('addToDo')
})
app.get('/deleteById/:id',async(req,res) =>{
    await ToDoList.destroy({
        
            where:{
                id: req.params.id
            }
    })
    res.redirect('/')
})

app.post('/addNewToDo',async(req,res) =>{
    await ToDoList.create(req.body);
    res.redirect('/addToDo')
})


app.listen(5000)