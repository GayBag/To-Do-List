const {Sequelize,DataTypes,Model} = require('sequelize');
const sequelize = new Sequelize('todo_base','root','',{
    host:'127.0.0.1',
    port:'3306',
    dialect:'mysql'
})
class ToDoList extends Model{};
ToDoList.init({
    id:{
        type:DataTypes.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    name:DataTypes.STRING
},
{
    modelName:'todolist',
    sequelize

})
ToDoList.sync();
module.exports = {ToDoList,sequelize}